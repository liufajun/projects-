var t = require("../../api.js"), a = getApp(), e = !1;

Page({
    data: {
       show: !1,
       deposit: 0.00,
      form: {
        number: 1
      },
    },
    onLoad: function(t) {
        a.pageOnLoad(this);
    },
    getData: function() {
      var n = this;
      wx.showLoading({
        title: "加载中"
      }), a.request({
        url: t.deposit.mine_deposit,
        data: {
        },
        success: function (t) {
          console.error(t.data);
          n.setData({
            deposit: t.data
          }), wx.hideLoading(), e = !1;
        },
        fail: function (e) {
          console.error(e);
        }
      });
      this.getRecord();
    },
    onReady: function() {
        a.pageOnReady(this);
    },
    onShow: function() {
        a.pageOnShow(this);
      this.getData();
     
    },
    onHide: function() {
        a.pageOnHide(this);
    },
    onUnload: function() {
        a.pageOnUnload(this);
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
  getRecord : function(){
    var n = this;
     a.request({
      url: t.deposit.record,
      data: {
      },
      success: function (t) {
        console.error(t.data);
        n.setData({
          list: t.data
        }), e = !1;
      },
      fail: function (e) {
        console.error(e);
      }
    });
  }, 
  buyNow: function () {
    this.submit();
  },
  submit: function () {
    var i = this;
    if (!i.data.show_attr_picker) return i.setData({
      show_attr_picker: !0
    }), !0;
    if (i.data.deposit && i.data.deposit.num > 0 && i.data.form.number > i.data.deposit.num) return wx.showToast({
      title: "退桶数量超出总的桶数量",
      image: "/images/icon-warning.png"
    }), !0;
    wx.showLoading({
      title: "正在提交",
      mask: !0
    }), a.request({
      url: t.deposit.refund,
      method: "POST",
      data: {
        id: i.data.deposit.id,
        refund: 5 * i.data.form.number,
        num: i.data.form.number
      },
      success: function (t) {
        wx.hideLoading(), wx.showToast({
          title: t.data.msg,
          duration: 1500
        }), 0 == t.code && i.getData(), i.hideAttrPicker();
      }
    })
  },
  hideAttrPicker: function () {
    this.setData({
      show_attr_picker: !1
    });
  },
  showAttrPicker: function () {
    this.setData({
      show_attr_picker: !0
    });
  },
  numberSub: function () {
    var t = this, a = t.data.form.number;
    if (a <= 1) return !0;
    a-- , t.setData({
      form: {
        number: a
      }
    });
  },
  numberAdd: function () {
    var t = this, a = t.data.form.number;
    a++ , a > t.data.deposit.num ? wx.showToast({
      title: '超出最大桶数量',
    }) : t.setData({
      form: {
        number: a
      }
    });
  },
  numberBlur: function (t) {
    var a = this, o = t.detail.value;
    o = parseInt(o), isNaN(o) && (o = 1), o <= 0 && (o = 1), a.setData({
      form: {
        number: o
      }
    });
  },
  agree: function (d) {
    var i = this;
    wx.showModal({
      title: '退押金申请',
      content: '是否同意？',
      success: function (s) {
        s.confirm && wx.showLoading({
          title: "正在提交",
          mask: !0
        }), a.request({
          url: t.deposit.agree,
          method: "POST",
          data: {
            id: d.currentTarget.dataset.id
          },
          success: function (t) {
            wx.hideLoading(), wx.showToast({
              title: t.msg,
              duration: 1500
            }), 0 == t.code && i.getRecord();
          }
        })
      }
    })
  }
});