require("../../api.js");

var n = getApp();

Page({
    data: {},
    onLoad: function(o) {
        n.pageOnLoad(this);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});