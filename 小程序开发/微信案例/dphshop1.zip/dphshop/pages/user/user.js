var e = require("../../api.js"), t = getApp();

Page({
  data: {
    contact_tel: "",
    show_customer_service: 0
  },
  onLoad: function (e) {
    t.pageOnLoad(this);
  },
  loadData: function (a) {
    var n = this;
    n.setData({
      store: wx.getStorageSync("store")
    });
    var i = wx.getStorageSync("pages_user_user");
    i && n.setData(i), t.request({
      url: e.user.index,
      success: function (e) {
        console.error(e);
        0 == e.code && (n.setData(e.data), wx.setStorageSync("pages_user_user", e.data),
          wx.setStorageSync("share_setting", e.data.share_setting), wx.setStorageSync("user_info", e.data.user_info));
      }
    });
  },
  onReady: function () { },
  onShow: function () {
    t.pageOnShow(this), this.loadData();
  },
  callTel: function (e) {
    var t = e.currentTarget.dataset.tel;
    wx.makePhoneCall({
      phoneNumber: t
    });
  },
  apply: function (a) {
    var i = wx.getStorageSync("user_info");
    (0 == i.is_dispatch ? wx.showModal({
      title: "申请成为配送员",
      content: "是否申请？",
      success: function (s) {
        s.confirm && (wx.showLoading({
          title: "正在加载",
          mask: !0
        }), t.request({
          url: e.dispatch.aplly,
          method: "POST",
          data: {
          },
          success: function (e) {
            0 == e.code && wx.showToast({
              title: e.msg,
            });
            1 == e.code && wx.showToast({
              title: e.msg,
            });
          },
          complete: function () {
            //wx.hideLoading();
          }
        }));
      }
    }) : wx.navigateTo({
      url: "/pages/add-share/index"
    }));
  },
  applyadmin: function (a) {
    var i = wx.getStorageSync("user_info");
    (0 == i.is_dispatch ? wx.showModal({
      title: "申请成为监督员",
      content: "是否申请？",
      success: function (s) {
        s.confirm && (wx.showLoading({
          title: "正在加载",
          mask: !0
        }), t.request({
          url: e.monitors.aplly,
          method: "POST",
          data: {
          },
          success: function (e) {
            0 == e.code && wx.showToast({
              title: e.msg,
            });
            1 == e.code && wx.showToast({
              title: e.msg,
            });
          },
          complete: function () {
            //wx.hideLoading();
          }
        }));
      }
    }) : wx.navigateTo({
      url: "/pages/add-share/index"
    }));
  },
  verify: function (e) {
    wx.scanCode({
      onlyFromCamera: !1,
      success: function (e) {
        wx.navigateTo({
          url: "/" + e.path
        });
      },
      fail: function (e) {
        wx.showToast({
          title: "失败"
        });
      }
    });
  },
  member: function () {
    wx.navigateTo({
      url: "/pages/member/member"
    });
  },
  integral_mall: function (e) {
    t.permission_list && t.permission_list.length && function (e, t) {
      return -1 != ("," + e.join(",") + ",").indexOf("," + t + ",");
    }(t.permission_list, "integralmall") && wx.navigateTo({
      url: "/pages/integral-mall/index/index"
    });
  }
});