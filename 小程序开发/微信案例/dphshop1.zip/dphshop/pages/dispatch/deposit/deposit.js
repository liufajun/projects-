var t = require("../../../api.js"), a = getApp(), e = !1;

Page({
    data: {
       show: !1,
       deposit: 0.00,
       status:1,
      record: true,
      getrefund: false,
      form: {
        number: 1
      },
    },
    onLoad: function(t) {
        a.pageOnLoad(this);
    },
    getData: function() {
      var n = this;
      wx.showLoading({
        title: "加载中"
      }), a.request({
        url: t.deposit.deposit,
        data: {
        },
        success: function (t) {
          console.error(t.data);
          n.setData({
            deposit: t.data,
            collect: t.data.customer
          }), wx.hideLoading(), e = !1;
        },
        fail: function (e) {
          console.error(e);
        }
      });
      this.getRecord();
    },
    onReady: function() {
        a.pageOnReady(this);
    },
    onShow: function() {
        a.pageOnShow(this);
      this.getData();
     
    },
    onHide: function() {
        a.pageOnHide(this);
    },
    onUnload: function() {
        a.pageOnUnload(this);
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
  getRecord : function(){
    var n = this;
     a.request({
       url: t.deposit.refundlist,
      data: {
      },
      success: function (t) {
        console.error(t.data);
        n.setData({
          list: t.data
        }), e = !1;
      },
      fail: function (e) {
        console.error(e);
      }
    });
  },
  inputuserid:function(e){
    this.setData({
      user_id: e.detail.value
    })
  },
  buyNow: function () {
    var i = this;
    if (!i.data.show_attr_picker) return i.setData({
      show_attr_picker: !0
    }), !0;
    if (i.data.user_id == -1 || i.data.user_id ==null){
      wx.showToast({
        title: '用户编号不能为空',
      })
      return;
    };
    wx.showLoading({
      title: "正在提交",
      mask: !0
    }), a.request({
      url: t.deposit.save,
      method: "POST",
      data: {
        user_id: i.data.user_id,
        deposit: 5 * i.data.form.number,
        num: i.data.form.number
      },
      success: function (t) {
        wx.hideLoading(), wx.showToast({
          title: t.data.msg,
          duration: 1500
        }), 0 == t.code && (wx.showToast({
          title: '保存成功',
        }),i.getData()) , i.hideAttrPicker(),1==t.code&&wx.showToast({
          title: t.data.msg,
        });
      }
    })
  },
  hideAttrPicker: function () {
    this.setData({
      show_attr_picker: !1
    });
  },
  showAttrPicker: function () {
    this.setData({
      show_attr_picker: !0
    });
  },
  numberSub: function () {
    var t = this, a = t.data.form.number;
    if (a <= 1) return !0;
    a-- , t.setData({
      form: {
        number: a
      }
    });
  },
  numberAdd: function () {
    var t = this, a = t.data.form.number;
    a++ , t.setData({
      form: {
        number: a
      }
    });
  },
  numberBlur: function (t) {
    var a = this, o = t.detail.value;
    o = parseInt(o), isNaN(o) && (o = 1), o <= 0 && (o = 1), a.setData({
      form: {
        number: o
      }
    });
  },
  agree :function(d){
    var i = this;
     wx.showModal({
       title: '退押金申请',
       content: '是否同意？',
       success:function(s){
         s.confirm && wx.showLoading({
           title: "正在提交",
           mask: !0
         }), a.request({
              url: t.deposit.agree,
              method: "POST",
              data: {
                id: d.currentTarget.dataset.id
              },
              success: function (t) {
                wx.hideLoading(), wx.showToast({
                  title: t.msg,
                  duration: 1500
                }), 0 == t.code && i.getRecord();
              }
            })
          }
     })
  },
  getrecord:function(){
    var i = this;
    this.getData();
    i.setData({
      status: 1,
      record: true,
      getrefund: false
    })
  },
  getrecord1: function () {
    var i = this;
    this.getData();
    i.setData({
      status: 2,
      record: false,
      getrefund: true
    })
  }
});