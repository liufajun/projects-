var t = require("../../../api.js"), a = getApp();

Page({
  data: {
    status:1,
    list:[]
  },
  onLoad: function (t) {
    a.pageOnLoad(this);
    this.getRecord(t);
  },
  onReady: function () {
    a.pageOnReady(this);
  },
  onShow: function () {
    a.pageOnShow(this);
  },
  onHide: function () {
    a.pageOnHide(this);
  },
  onUnload: function () {
    a.pageOnUnload(this);
  },
  onPullDownRefresh: function () { },
  onReachBottom: function () { },
  getRecord: function (d) {
    var n = this;
    n.setData({
      status: d.status
    }),wx.showLoading({
      title: '加载数据中...',
    }),a.request({
      url: t.dispatch.dispatchs,
      method:'POST',
      data: {
        status: d.status == null ? 1 : d.status
      },
      success: function (t) {
        console.error(t.data);
        t.code==0&&(n.setData({
          list: t.data.dispatch_list
        }), wx.hideLoading(), n.data.list&&n.setData({
          show_no_data_tip: 0 == n.data.list.length 
        }));
        t.code == 1 && n.setData({
          show_no_data_tip: 1,
          list :[]
        }), wx.hideLoading();
      },
      fail: function (e) {
        console.error(e);
      }
    });
  },
  dispatch:function(d){
    var n = this;
    console.error(d.currentTarget.dataset.id);
    a.request({
      url: t.dispatch.start,
      method: "POST",
      data: {
        id: d.currentTarget.dataset.id,
        orderid: d.currentTarget.dataset.oid
      },
      success: function (t) {
        console.error(t.data);
        t.code==0 && (wx.showToast({
          title: t.data.msg,
        }), n.getRecord(n.data));
      },
      fail: function (e) {
        console.error(e);
      }
    });
  },
 dispatchover: function (d) {
    var n = this;
    console.error(d.currentTarget.dataset.id);
    a.request({
      url: t.dispatch.over,
      method: "POST",
      data: {
        id: d.currentTarget.dataset.id
      },
      success: function (t) {
        console.error(t.data);
        t.code == 0 && (wx.showToast({
          title: t.data.msg,
        }), n.getRecord(n.data));
      },
      fail: function (e) {
        console.error(e);
      }
    });
  },
  callTel: function (e) {
    var t = e.currentTarget.dataset.tel;
    wx.makePhoneCall({
      phoneNumber: t
    });
  },
});