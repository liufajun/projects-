// import ApiList from  '../../config/api';
// import request from '../../utils/request.js';
//获取应用实例  
var app = getApp();
Page({
    data: {
        // types: null,
        typeTree: {}, // 数据缓存
        currType: 0 ,
        // 当前类型
        "types": [
        ],
        typeTree: [],
        page: 2,
        catId: 0,
        brandId: 0,
        ptype: ''
    },
        
    onLoad: function (option){
        var that = this;
        wx.request({
            url: app.d.ceshiUrl + '/Api/Category/index',
            method:'post',
            data: {},
            header: {
                'Content-Type':  'application/x-www-form-urlencoded'
            },
            success: function (res) {
                //--init data 
                var status = res.data.status;
                if(status==1) { 
                    var list = res.data.list;
                    var catList = res.data.catList;
                  //获取第一个数据
                  if (catList.length > 0)
                    that.getData(catList[0]['id']);
                  that.setData({
                      types:list,
                      typeTree:catList,
                  });
                 
                } else {
                    wx.showToast({
                        title:res.data.err,
                        duration:2000,
                    });
                }
                  that.setData({
                      currType: 0
                  });    
                console.log(list)
            },
                error:function(e){
                wx.showToast({
                    title:'网络异常！',
                    duration:2000,
                });
            },

        });
    },    
 
    tapType: function (e){
        var that = this;
        const currType = e.currentTarget.dataset.typeId;

        that.setData({
            currType: currType
        });
        console.log(currType);
        var cat_id = e.currentTarget.dataset.catId;
        var ptype = 0;
        var brandId = 9;
        console.log(cat_id);
        //ajax请求数据
        wx.request({
          url: app.d.ceshiUrl + '/Api/Product/lists',
          method: 'post',
          data: {
            cat_id: cat_id,
            ptype: ptype,
            brand_id: brandId
          },
          header: {
            'content-type': 'application/x-www-form-urlencoded'
          },
          success: function (res) {
            var shoplist = res.data.pro;
            that.setData({
              shopList: shoplist
            })
          },
          error: function (e) {
            wx.showToast({
              title: '网络异常！',
              duration: 2000
            });
          }
        });
    },
    // 加载品牌、二级类目数据
    getTypeTree (currType) {
        const me = this, _data = me.data;
        if(!_data.typeTree[currType]){
            request({
                url: ApiList.goodsTypeTree,
                data: {typeId: +currType},
                success: function (res) {
                    _data.typeTree[currType] = res.data.data;
                    me.setData({
                        typeTree: _data.typeTree
                    });
                }
            });
        }
    },
  getData(cat_id){
      var that = this;
      var ptype = 0;
      var brandId = 9;
      //ajax请求数据
      wx.request({
        url: app.d.ceshiUrl + '/Api/Product/lists',
        method: 'post',
        data: {
          cat_id: cat_id,
          ptype: ptype,
          brand_id: brandId
        },
        header: {
          'content-type': 'application/x-www-form-urlencoded'
        },
        success: function (res) {
          var shoplist = res.data.pro;
          that.setData({
            shopList: shoplist
          })
        },
        error: function (e) {
          wx.showToast({
            title: '网络异常！',
            duration: 2000
          });
        }
      });
    },
    //点击加载更多
    getMore: function (e) {
      var that = this;
      var page = that.data.page;
      wx.request({
        url: app.d.ceshiUrl + '/Api/Product/get_more',
        method: 'post',
        data: {
          page: page,
          ptype: that.data.ptype,
          cat_id: that.data.catId,
          brand_id: that.data.brandId
        },
        header: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        success: function (res) {
          var prolist = res.data.pro;
          if (prolist == '') {
            wx.showToast({
              title: '没有更多数据！',
              duration: 2000
            });
            return false;
          }
          //that.initProductData(data);
          that.setData({
            page: page + 1,
            shopList: that.data.shopList.concat(prolist)
          });
          //endInitData
        },
        fail: function (e) {
          wx.showToast({
            title: '网络异常！',
            duration: 2000
          });
        }
      })
  },
  onReachBottom: function () {
    //下拉加载更多多...
    this.getMore();
  }
})