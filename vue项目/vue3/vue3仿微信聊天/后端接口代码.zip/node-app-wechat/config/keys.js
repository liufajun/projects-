module.exports = {
  // mongoURI: 'mongodb://test:123abc@ds227853.mlab.com:27853/wchart-api',
  mongoURI: 'mongodb://wxapi:test1234@ds135983.mlab.com:35983/wx-api',
  secretOrKey: 'secret'
};
